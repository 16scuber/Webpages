const model = require('../models/page');

exports.contact = (req, res) => {
    res.render('contact');
};

exports.about = (req, res) => {
    res.render('about');
};