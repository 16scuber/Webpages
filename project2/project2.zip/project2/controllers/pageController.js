const model = require('../models/page');

exports.trades = (req, res) => {
    let pages = model.find();
    res.render('./page/trades');
};

exports.newTrade = (req, res) => {
    res.render('./page/newTrade');
};

exports.trade = (req, res) => {
    res.render('./page/trade');
};

