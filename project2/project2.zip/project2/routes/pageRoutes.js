const { application } = require('express');
const express = require('express');
const controller = require('../controllers/pageController');

const router = express.Router();
const app = express();

//GET /stories/new: send html form for creating a new trade

router.get('/newTrade', controller.newTrade);

//router.get('/trades', controller.trades);
app.get('/trades', function(req, res) {
    res.send("working");
});

router.get('/trade', controller.trade);

module.exports = router;