const { DateTime } = require('luxon');
const {v4: uuidv4} = require('uuid');
const pages = [
    {
        id: '1',
        title: 'A funny story',
        category: 'Lorem ipsum dolor sit amet. Sit facilis autem qui quia sint a doloribus atque et quasi odit in saepe facere nam nemo corrupti in repudiandae tenetur.',
        details: 'Lijuan', 
        status: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    
    },
    { 
        id: '1',
        title: 'A funny story',
        category: 'Lorem ipsum dolor sit amet. Sit facilis autem qui quia sint a doloribus atque et quasi odit in saepe facere nam nemo corrupti in repudiandae tenetur.',
        details: 'Lijuan', 
        status: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    }
];

exports.find = () => pages;

exports.findById = id => pages.find(page=>page.id === id);

exports.save = function (page) {
    page.id = uuidv4();
    page.createdAt = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    pages.push(page);
};

exports.updateById = function(id, newPage) {
    let page = pages.find(page=>page.id === id);
    if(page) {
        page.title = newPage.title;
        page.content = newPage.content;
        return true;
    } else {
        return false;
    }
}

exports.deleteById = function(id) {
    let index = pages.find(page => page.id === id);
    if(index !== -1) {
        pages.splice(index, 1);
        return true;
    } else {
        return false;
    }
}